select asewkt(the_geom) from loadedshp;

